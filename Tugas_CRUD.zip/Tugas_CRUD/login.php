<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>bootstrap</title>
    <link rel="stylesheet" href="../style/login.css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<!-- <style>
  .card{
    width: 500px
  }
</style> -->
<style>
    body{
        background-image: url('https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/a44778ea-3457-40e0-8979-b7e3685d23d0/deyvjkp-3da54fc1-c369-4ffe-a552-ebf916488a4a.png/v1/fill/w_1192,h_670/fanny_aspirants_4k_png_mlbb__anime__by_newjer53_deyvjkp-pre.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NzIwIiwicGF0aCI6IlwvZlwvYTQ0Nzc4ZWEtMzQ1Ny00MGUwLTg5NzktYjdlMzY4NWQyM2QwXC9kZXl2amtwLTNkYTU0ZmMxLWMzNjktNGZmZS1hNTUyLWViZjkxNjQ4OGE0YS5wbmciLCJ3aWR0aCI6Ijw9MTI4MCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.M6rl-iMEhy81xBSeE3JPuNRVREPP0gttCXOpG6izxJE');
    }
</style>
<body >
  <div class="container py-5 ">
<div class="card w-50 justify-content-center mx-auto bg-transparent">
<div class="header">
    <h2 class="text-center pt-3 text-primary">LOGIN PAGE</h2>
</div>
  
<form action="connect_login.php" method="post" >
    <div class="card-body">
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email </label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1">
    </div>
  </div>
 <div class="text-center pb-3">
 <button type="submit" class="btn btn-primary">Submit</button>
 </div>
        </form>
        </div>
        </div>
</body>
</html>
